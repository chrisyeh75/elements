var searchData=
[
  ['deleteemptyspace',['deleteEmptySpace',['../class_game.html#ace65c584cceee8977942ace8ad86d080',1,'Game']]]
];
